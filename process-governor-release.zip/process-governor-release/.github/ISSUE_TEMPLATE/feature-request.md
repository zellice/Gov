---
name: "Feature request"
about: Suggest an idea
title: ''
labels: enhancement
assignees: ''

---

## Summary

Brief explanation of the feature.

### Basic example

Include a basic example or links here.

### Motivation

Why are we doing this? What use cases does it support? What is the expected outcome?
