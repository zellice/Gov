from enum import StrEnum


class SelectorType(StrEnum):
    NAME = "Name"
    PATH = "Path"
    CMDLINE = "CommandLine"
