from enum import StrEnum


class BoolStr(StrEnum):
    NO = "N"
    YES = "Y"
