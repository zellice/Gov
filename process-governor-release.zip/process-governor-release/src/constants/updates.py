from typing import Final

API_UPDATE_URL: Final[str] = "https://api.github.com/repos/SystemXFiles/process-governor/releases/latest"
UPDATE_URL: Final[str] = "https://github.com/SystemXFiles/process-governor/releases/latest"
