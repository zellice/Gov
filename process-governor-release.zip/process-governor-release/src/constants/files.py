from typing import Final

LOCK_FILE_NAME: Final[str] = "pg.lock"

CONFIG_FILE_NAME: Final[str] = "config.json"
CONFIG_FILE_ENCODING: Final[str] = "utf-8"
LOG_FILE_NAME: Final[str] = "logging.txt"
